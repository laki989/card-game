# 🎴 Mexico Card Game - Complete File Structure

## 📁 Root Directory Structure

```
mexico-card-game/                    ← Your project folder
│
├── server.js                         ← ✅ Node.js backend server
├── package.json                      ← ✅ NPM dependencies
├── README.md                         ← Optional documentation
├── .gitignore                        ← Optional for Git
│
└── public/                           ← ✅ Frontend files (served by Express)
    │
    ├── index.html                    ← ✅ Main HTML file (25 lines)
    ├── styles.css                    ← ✅ All CSS styles (600 lines)
    ├── app.js                        ← ✅ React application (550 lines)
    │
    └── img/                          ← ⚠️ Images folder (YOU NEED TO ADD IMAGES)
        │
        ├── table_background.png      ← ✅ Poker table background
        ├── player_card.png           ← ✅ Player info card template
        │
        ├── back.webp                 ← ⚠️ Card back design (ADD THIS)
        │
        ├── H-A.webp                  ← ⚠️ Hearts Ace (ADD THESE 32 CARDS)
        ├── H-K.webp                  ← ⚠️ Hearts King
        ├── H-Q.webp                  ← ⚠️ Hearts Queen
        ├── H-J.webp                  ← ⚠️ Hearts Jack
        ├── H-10.webp
        ├── H-09.webp
        ├── H-08.webp
        ├── H-07.webp
        │
        ├── B-A.webp                  ← ⚠️ Bells Ace
        ├── B-K.webp
        ├── B-Q.webp
        ├── B-J.webp
        ├── B-10.webp
        ├── B-09.webp
        ├── B-08.webp
        ├── B-07.webp
        │
        ├── L-A.webp                  ← ⚠️ Leaves Ace
        ├── L-K.webp
        ├── L-Q.webp
        ├── L-J.webp
        ├── L-10.webp
        ├── L-09.webp
        ├── L-08.webp
        ├── L-07.webp
        │
        ├── A-A.webp                  ← ⚠️ Acorns Ace
        ├── A-K.webp
        ├── A-Q.webp
        ├── A-J.webp
        ├── A-10.webp
        ├── A-09.webp
        ├── A-08.webp
        └── A-07.webp
```

---

## ✅ Files Ready (Download These)

1. **server.js** - Backend with all features ✅
2. **public/index.html** - Clean HTML skeleton ✅
3. **public/styles.css** - Complete CSS ✅
4. **public/app.js** - Full React app ✅
5. **public/img/table_background.png** - Poker table ✅
6. **public/img/player_card.png** - Player card ✅

---

## ⚠️ Files YOU Need to Add

### **Card Images (33 total)**

You mentioned you have these ready. Place them in `public/img/`:

#### Naming Convention:
- **Hearts:** H-A.webp, H-K.webp, H-Q.webp, H-J.webp, H-10.webp, H-09.webp, H-08.webp, H-07.webp
- **Bells:** B-A.webp, B-K.webp, B-Q.webp, B-J.webp, B-10.webp, B-09.webp, B-08.webp, B-07.webp
- **Leaves:** L-A.webp, L-K.webp, L-Q.webp, L-J.webp, L-10.webp, L-09.webp, L-08.webp, L-07.webp
- **Acorns:** A-A.webp, A-K.webp, A-Q.webp, A-J.webp, A-10.webp, A-09.webp, A-08.webp, A-07.webp
- **Card Back:** back.webp

#### Important:
- **File names are case-sensitive**
- Must be `.webp` format
- Must be exact names (e.g., `H-09.webp` not `H-9.webp`)

---

## 📋 Setup Steps

### 1. Create Directory Structure
```bash
mkdir -p mexico-card-game/public/img
cd mexico-card-game
```

### 2. Download Files
Download all the files I provided and place them:
- `server.js` → root folder
- `package.json` → root folder
- `index.html` → public/
- `styles.css` → public/
- `app.js` → public/
- `table_background.png` → public/img/
- `player_card.png` → public/img/

### 3. Add Your Card Images
Copy all 33 card images to `public/img/` with correct names

### 4. Install & Run
```bash
npm install
npm start
```

### 5. Open Game
Open browser: `http://localhost:3000`

---

## 🔍 Quick Check

Before running, verify this structure:

```bash
ls -R mexico-card-game/
```

Should show:
```
mexico-card-game/:
server.js  package.json  public/

mexico-card-game/public:
index.html  styles.css  app.js  img/

mexico-card-game/public/img:
table_background.png  player_card.png  back.webp
H-A.webp  H-K.webp  H-Q.webp  ...  (32 card images)
A-A.webp  A-K.webp  A-Q.webp  ...
```

---

## ✨ Features Included

✅ **Betl Bidding** - Special bid with +7/-7 scoring
✅ **First Player Rules** - Cannot pass, must bid 5+
✅ **Bidding Rules** - Others can't bid 5
✅ **3-Second Trick Delay** - Shows winner
✅ **Menu System** - Reset game / Leave game
✅ **Poker Table Layout** - Professional design
✅ **Overlapping Cards** - 20% overlap in hand
✅ **Real Card Images** - Your Hungarian cards
✅ **Game Named Mexico** - Changed everywhere

---

## 🎯 Final Checklist

- [ ] All files in correct folders
- [ ] 33 card images with exact names
- [ ] `npm install` completed
- [ ] Server starts without errors
- [ ] Can access http://localhost:3000
- [ ] Cards display correctly
- [ ] 3 players can join and play

---

## 🆘 Troubleshooting

**Cards don't show:**
→ Check file names match exactly (H-09.webp not H-9.webp)
→ Verify all 33 images are in public/img/

**Cannot GET /:**
→ Make sure public/ folder contains index.html
→ Check server.js is serving static files

**Connection errors:**
→ Make sure port 3000 is free
→ Check firewall settings

---

You're all set! Just add your card images and you're ready to play! 🎴🎉
