function sortHand(hand) {
  return [...hand].sort((a, b) => {
    const suitDiff = SUIT_ORDER.indexOf(a.suit) - SUIT_ORDER.indexOf(b.suit);
    if (suitDiff !== 0) return suitDiff;
    return RANK_ORDER[b.rank] - RANK_ORDER[a.rank];
  });
}

function getCardImagePath(card) {
  const suitPrefix = { 'hearts': 'H', 'bells': 'B', 'leaves': 'L', 'acorns': 'A' };
  const rankSuffix = { 'A': 'A', 'K': 'K', 'Q': 'Q', 'J': 'J', '10': '10', '9': '09', '8': '08', '7': '07' };
  return `img/${suitPrefix[card.suit]}-${rankSuffix[card.rank]}.webp`;
}

function getNextRank(rank) {
  const sequence = ['7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  const index = sequence.indexOf(rank);
  return sequence[(index + 1) % 8];
}
