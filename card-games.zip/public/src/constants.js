const { useState, useEffect, useRef } = React;

const SUIT_SYMBOLS = {
  'acorns': '🌰',
  'leaves': '🍃',
  'hearts': '♥️',
  'bells': '🔔'
};

const RANK_ORDER = { 'A': 7, 'K': 6, 'Q': 5, 'J': 4, '10': 3, '9': 2, '8': 1, '7': 0 };
const SUIT_ORDER = ['hearts', 'bells', 'leaves', 'acorns'];

const LORUM_CONTRACTS = [
  { id: 1, name: 'Minimum', nameLocal: 'Minimum', description: 'Avoid tricks (+1 per trick)' },
  { id: 2, name: 'Maximum', nameLocal: 'Maksimum', description: 'Win 2+ tricks (0-1 = +8)' },
  { id: 3, name: 'Queens', nameLocal: 'Dame', description: 'Avoid queens (+2 per queen)' },
  { id: 4, name: 'Hearts', nameLocal: 'Srca', description: 'Avoid hearts (+1 each) or take all (-8)' },
  { id: 5, name: 'Jack of Clubs', nameLocal: 'Žandar tref', description: 'Avoid Jack of Clubs (+8)' },
  { id: 6, name: 'King of Hearts', nameLocal: 'Kralj srce', description: 'Avoid King of Hearts (+8)' },
  { id: 7, name: 'Lora', nameLocal: 'Ređanje', description: 'First out (-8), others (+1 per card + pass)' }
];
