const { useState, useEffect, useRef } = React;

// Constants
const SUIT_SYMBOLS = {
  'acorns': '🌰',
  'leaves': '🍃',
  'hearts': '♥️',
  'bells': '🔔'
};

const RANK_ORDER = { 'A': 7, 'K': 6, 'Q': 5, 'J': 4, '10': 3, '9': 2, '8': 1, '7': 0 };
const SUIT_ORDER = ['hearts', 'bells', 'leaves', 'acorns'];

// Helper Functions
function sortHand(hand) {
  return [...hand].sort((a, b) => {
    const suitDiff = SUIT_ORDER.indexOf(a.suit) - SUIT_ORDER.indexOf(b.suit);
    if (suitDiff !== 0) return suitDiff;
    return RANK_ORDER[b.rank] - RANK_ORDER[a.rank];
  });
}

function getCardImagePath(card) {
  const suitPrefix = { 'hearts': 'H', 'bells': 'B', 'leaves': 'L', 'acorns': 'A' };
  const rankSuffix = { 'A': 'A', 'K': 'K', 'Q': 'Q', 'J': 'J', '10': '10', '9': '09', '8': '08', '7': '07' };
  return `img/${suitPrefix[card.suit]}-${rankSuffix[card.rank]}.webp`;
}

// Card Component
function Card({ card, onClick, disabled }) {
  return (
    <div className={`card ${disabled ? 'disabled' : ''}`} onClick={disabled ? undefined : onClick}>
      <img src={getCardImagePath(card)} alt={`${card.rank} of ${card.suit}`} />
    </div>
  );
}

// Game History Modal
function GameHistory({ history, players, onClose }) {
  return (
    <div className="modal" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <h2>Game History</h2>
        {history.length === 0 ? <p>No rounds played yet.</p> : (
          history.map((round, idx) => (
            <div key={idx} className="history-entry">
              <h3>Round {idx + 1}</h3>
              <p><strong>Dealer:</strong> {players[round.dealer]?.name}</p>
              <p><strong>Winner:</strong> {players[round.bidWinner]?.name} (bid: {round.bids[round.bidWinner]})</p>
              {round.isBetl && <p><strong>Type:</strong> Betl</p>}
              {round.trump && <p><strong>Trump:</strong> {SUIT_SYMBOLS[round.trump]}</p>}
              <p><strong>Tricks:</strong> {round.tricksTaken.map((t, i) => `${players[i]?.name}: ${t}`).join(', ')}</p>
              <p><strong>Round Scores:</strong> {round.roundScores.map((s, i) => `${players[i]?.name}: ${s > 0 ? '+' : ''}${s}`).join(', ')}</p>
              <p><strong>Total:</strong> {round.totalScores.map((s, i) => `${players[i]?.name}: ${s}`).join(', ')}</p>
            </div>
          ))
        )}
        <button className="close-button" onClick={onClose}>Close</button>
      </div>
    </div>
  );
}

// Chat Component (from previous)
function Chat({ socket, gameCode, playerIndex }) {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (!socket) return;

    socket.on('chat_message', ({ playerName, playerIndex: senderIndex, message, timestamp }) => {
      setMessages(prev => [...prev, { playerName, playerIndex: senderIndex, message, timestamp }]);
    });

    return () => {
      socket.off('chat_message');
    };
  }, [socket]);

  useEffect(() => {
    if (!isMinimized) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isMinimized]);

  const sendMessage = () => {
    if (!inputMessage.trim()) return;
    socket.emit('chat_message', { gameId: gameCode, message: inputMessage.trim() });
    setInputMessage('');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className={`chat-panel ${isMinimized ? 'minimized' : ''}`}>
      <div className="chat-header">
        <span className="chat-title">💬 Chat</span>
        <button className="chat-toggle" onClick={() => setIsMinimized(!isMinimized)}>
          {isMinimized ? '▲' : '▼'}
        </button>
      </div>
      
      {!isMinimized && (
        <>
          <div className="chat-messages">
            {messages.map((msg, idx) => (
              <div key={idx} className={`chat-message ${msg.playerIndex === playerIndex ? 'own' : ''}`}>
                <div className="chat-message-header">
                  <span className="chat-message-player">{msg.playerName}</span>
                  <span className="chat-message-time">{formatTime(msg.timestamp)}</span>
                </div>
                <div className="chat-message-text">{msg.message}</div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="chat-input-area">
            <input
              type="text"
              className="chat-input"
              placeholder="Type a message..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              maxLength={200}
            />
            <button 
              className="chat-send-button" 
              onClick={sendMessage}
              disabled={!inputMessage.trim()}
            >
              Send
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// Main Game Coordinator
function GameCoordinator() {
  const [socket, setSocket] = useState(null);
  const [gameState, setGameState] = useState(null);
  const [playerIndex, setPlayerIndex] = useState(null);
  const [gameCode, setGameCode] = useState(null);
  const [gameType, setGameType] = useState(null);
  const [error, setError] = useState(null);

  const socketRef = useRef(null);

  // Socket Connection
  useEffect(() => {
    if (socketRef.current) {
      console.log('Socket already exists');
      return;
    }

    console.log('Initializing socket...');
    const newSocket = io();
    socketRef.current = newSocket;
    setSocket(newSocket);

    newSocket.on('connect', () => console.log('Connected:', newSocket.id));
    
    newSocket.on('game_created', ({ gameId, playerIndex: pIdx, gameType: gType }) => {
      console.log('Game created:', gameId, 'Type:', gType);
      setGameCode(gameId);
      setPlayerIndex(pIdx);
      setGameType(gType);
    });
    
    newSocket.on('game_joined', ({ gameId, playerIndex: pIdx, gameType: gType }) => {
      console.log('Game joined:', gameId, 'Type:', gType);
      setGameCode(gameId);
      setPlayerIndex(pIdx);
      setGameType(gType);
    });
    
    newSocket.on('game_state', (state) => {
      console.log('State updated:', state.state);
      setGameState(state);
    });
    
    newSocket.on('error', ({ message }) => {
      console.error('Error:', message);
      setError(message);
      setTimeout(() => setError(null), 3000);
    });
    
    newSocket.on('player_left', ({ playerIndex }) => {
      alert(`Player ${playerIndex + 1} left`);
    });
    
    newSocket.on('disconnect', (reason) => console.log('Disconnected:', reason));

    return () => {
      console.log('Cleanup');
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
    };
  }, []);

  const handleCreateGame = (playerName, gameConfig) => {
    socket.emit('create_game', { playerName, gameConfig });
  };
  
  const handleJoinGame = (gameId, playerName) => {
    socket.emit('join_game', { gameId, playerName });
  };

  const handleError = (message) => {
    setError(message);
    setTimeout(() => setError(null), 3000);
  };

  // Show lobby if no game state
  if (!gameState) {
    // Load GameSelectionLobby component
    return React.createElement(
      'script',
      { 
        src: 'components/GameSelectionLobby.js',
        onLoad: () => {
          if (window.GameSelectionLobby) {
            ReactDOM.render(
              React.createElement(window.GameSelectionLobby, {
                onCreateGame: handleCreateGame,
                onJoinGame: handleJoinGame
              }),
              document.getElementById('lobby-root')
            );
          }
        }
      }
    );
  }

  // Waiting room
  if (gameState.state === 'waiting') {
    const maxPlayers = gameType === 'lorum' ? 4 : 3;
    return (
      <div className="lobby">
        <h1>{gameType === 'lorum' ? '🃏 Lorum' : '🎴 Mexico'}</h1>
        <div className="game-code">Code: {gameCode}</div>
        <div className="waiting-message">
          Waiting... ({gameState.players.length}/{maxPlayers})
          <br/><br/>
          {gameState.players.map((p, i) => <div key={i}>{i + 1}. {p.name}</div>)}
        </div>
      </div>
    );
  }

  // Route to appropriate game component
  return (
    <div className="game-container">
      {/* Error Toast */}
      {error && (
        <div style={{
          position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)',
          background: 'var(--red)', color: 'white', padding: '15px 30px',
          borderRadius: '8px', zIndex: 2000, fontWeight: 600
        }}>
          {error}
        </div>
      )}

      {/* Chat Panel */}
      <Chat socket={socket} gameCode={gameCode} playerIndex={playerIndex} />

      {/* Game Component */}
      {gameType === 'mexico' ? (
        <script src="games/MexicoGame.js" />
      ) : gameType === 'lorum' ? (
        <script src="games/LorumGame.js" />
      ) : null}
    </div>
  );
}

// Render
ReactDOM.render(<GameCoordinator />, document.getElementById('root'));
