#!/usr/bin/env python3
"""
Auto-assembler for final app.js
Combines all component files into one working app.js
"""

import os

# File paths
BASE_DIR = "/mnt/user-data/outputs/public"
OUTPUT_FILE = os.path.join(BASE_DIR, "app.js")

# Read component files
with open(os.path.join(BASE_DIR, "components/GameSelectionLobby.js"), 'r') as f:
    game_selection = f.read()

with open(os.path.join(BASE_DIR, "games/MexicoGame.js"), 'r') as f:
    mexico_game = f.read()

with open(os.path.join(BASE_DIR, "games/LorumGame.js"), 'r') as f:
    lorum_game = f.read()

# Create final app.js
final_app = f'''const {{ useState, useEffect, useRef }} = React;

// ============================================================================
// CONSTANTS & HELPERS
// ============================================================================

const SUIT_SYMBOLS = {{
  'acorns': '🌰',
  'leaves': '🍃',
  'hearts': '♥️',
  'bells': '🔔'
}};

const RANK_ORDER = {{ 'A': 7, 'K': 6, 'Q': 5, 'J': 4, '10': 3, '9': 2, '8': 1, '7': 0 }};
const SUIT_ORDER = ['hearts', 'bells', 'leaves', 'acorns'];

const LORUM_CONTRACTS = [
  {{ id: 1, name: 'Minimum', nameLocal: 'Minimum', description: 'Avoid tricks (+1 per trick)' }},
  {{ id: 2, name: 'Maximum', nameLocal: 'Maksimum', description: 'Win 2+ tricks (0-1 = +8)' }},
  {{ id: 3, name: 'Queens', nameLocal: 'Dame', description: 'Avoid queens (+2 per queen)' }},
  {{ id: 4, name: 'Hearts', nameLocal: 'Srca', description: 'Avoid hearts (+1 each) or take all (-8)' }},
  {{ id: 5, name: 'Jack of Clubs', nameLocal: 'Žandar tref', description: 'Avoid Jack of Clubs (+8)' }},
  {{ id: 6, name: 'King of Hearts', nameLocal: 'Kralj srce', description: 'Avoid King of Hearts (+8)' }},
  {{ id: 7, name: 'Lora', nameLocal: 'Ređanje', description: 'First out (-8), others (+1 per card + pass)' }}
];

function sortHand(hand) {{
  return [...hand].sort((a, b) => {{
    const suitDiff = SUIT_ORDER.indexOf(a.suit) - SUIT_ORDER.indexOf(b.suit);
    if (suitDiff !== 0) return suitDiff;
    return RANK_ORDER[b.rank] - RANK_ORDER[a.rank];
  }});
}}

function getCardImagePath(card) {{
  const suitPrefix = {{ 'hearts': 'H', 'bells': 'B', 'leaves': 'L', 'acorns': 'A' }};
  const rankSuffix = {{ 'A': 'A', 'K': 'K', 'Q': 'Q', 'J': 'J', '10': '10', '9': '09', '8': '08', '7': '07' }};
  return `img/${{suitPrefix[card.suit]}}-${{rankSuffix[card.rank]}}.webp`;
}}

function getNextRank(rank) {{
  const sequence = ['7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
  const index = sequence.indexOf(rank);
  return sequence[(index + 1) % 8];
}}

// ============================================================================
// SHARED COMPONENTS
// ============================================================================

function Card({{ card, onClick, disabled }}) {{
  return (
    <div className={{`card ${{disabled ? 'disabled' : ''}}`}} onClick={{disabled ? undefined : onClick}}>
      <img src={{getCardImagePath(card)}} alt={{`${{card.rank}} of ${{card.suit}}`}} />
    </div>
  );
}}

function GameHistory({{ history, players, onClose }}) {{
  return (
    <div className="modal" onClick={{onClose}}>
      <div className="modal-content" onClick={{(e) => e.stopPropagation()}}>
        <h2>Game History</h2>
        {{history.length === 0 ? <p>No rounds played yet.</p> : (
          history.map((round, idx) => (
            <div key={{idx}} className="history-entry">
              <h3>Round {{idx + 1}}</h3>
              <p><strong>Dealer:</strong> {{players[round.dealer]?.name}}</p>
              <p><strong>Winner:</strong> {{players[round.bidWinner]?.name}} (bid: {{round.bids[round.bidWinner]}})</p>
              {{round.isBetl && <p><strong>Type:</strong> Betl</p>}}
              {{round.trump && <p><strong>Trump:</strong> {{SUIT_SYMBOLS[round.trump]}}</p>}}
              <p><strong>Tricks:</strong> {{round.tricksTaken.map((t, i) => `${{players[i]?.name}}: ${{t}}`).join(', ')}}</p>
              <p><strong>Round Scores:</strong> {{round.roundScores.map((s, i) => `${{players[i]?.name}}: ${{s > 0 ? '+' : ''}}${{s}}`).join(', ')}}</p>
              <p><strong>Total:</strong> {{round.totalScores.map((s, i) => `${{players[i]?.name}}: ${{s}}`).join(', ')}}</p>
            </div>
          ))
        )}}
        <button className="close-button" onClick={{onClose}}>Close</button>
      </div>
    </div>
  );
}}

function Chat({{ socket, gameCode, playerIndex }}) {{
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState('');
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {{
    if (!socket) return;
    socket.on('chat_message', ({{ playerName, playerIndex: senderIndex, message, timestamp }}) => {{
      setMessages(prev => [...prev, {{ playerName, playerIndex: senderIndex, message, timestamp }}]);
    }});
    return () => {{ socket.off('chat_message'); }};
  }}, [socket]);

  useEffect(() => {{
    if (!isMinimized) {{
      messagesEndRef.current?.scrollIntoView({{ behavior: 'smooth' }});
    }}
  }}, [messages, isMinimized]);

  const sendMessage = () => {{
    if (!inputMessage.trim()) return;
    socket.emit('chat_message', {{ gameId: gameCode, message: inputMessage.trim() }});
    setInputMessage('');
  }};

  const handleKeyPress = (e) => {{
    if (e.key === 'Enter') sendMessage();
  }};

  const formatTime = (timestamp) => {{
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', {{ hour: '2-digit', minute: '2-digit' }});
  }};

  return (
    <div className={{`chat-panel ${{isMinimized ? 'minimized' : ''}}`}}>
      <div className="chat-header">
        <span className="chat-title">💬 Chat</span>
        <button className="chat-toggle" onClick={{() => setIsMinimized(!isMinimized)}}>
          {{isMinimized ? '▲' : '▼'}}
        </button>
      </div>
      {{!isMinimized && (
        <>
          <div className="chat-messages">
            {{messages.map((msg, idx) => (
              <div key={{idx}} className={{`chat-message ${{msg.playerIndex === playerIndex ? 'own' : ''}}`}}>
                <div className="chat-message-header">
                  <span className="chat-message-player">{{msg.playerName}}</span>
                  <span className="chat-message-time">{{formatTime(msg.timestamp)}}</span>
                </div>
                <div className="chat-message-text">{{msg.message}}</div>
              </div>
            ))}}
            <div ref={{messagesEndRef}} />
          </div>
          <div className="chat-input-area">
            <input
              type="text"
              className="chat-input"
              placeholder="Type a message..."
              value={{inputMessage}}
              onChange={{(e) => setInputMessage(e.target.value)}}
              onKeyPress={{handleKeyPress}}
              maxLength={{200}}
            />
            <button className="chat-send-button" onClick={{sendMessage}} disabled={{!inputMessage.trim()}}>
              Send
            </button>
          </div>
        </>
      )}}
    </div>
  );
}}

// ============================================================================
// GAME SELECTION LOBBY
// ============================================================================

{game_selection}

// ============================================================================
// MEXICO GAME COMPONENT
// ============================================================================

{mexico_game}

// ============================================================================
// LORUM GAME COMPONENT  
// ============================================================================

{lorum_game}

// ============================================================================
// MAIN GAME COORDINATOR
// ============================================================================

function GameCoordinator() {{
  const [socket, setSocket] = useState(null);
  const [gameState, setGameState] = useState(null);
  const [playerIndex, setPlayerIndex] = useState(null);
  const [gameCode, setGameCode] = useState(null);
  const [gameType, setGameType] = useState(null);
  const [error, setError] = useState(null);
  const socketRef = useRef(null);

  useEffect(() => {{
    if (socketRef.current) return;
    const newSocket = io();
    socketRef.current = newSocket;
    setSocket(newSocket);

    newSocket.on('connect', () => console.log('Connected'));
    newSocket.on('game_created', ({{ gameId, playerIndex: pIdx, gameType: gType }}) => {{
      setGameCode(gameId);
      setPlayerIndex(pIdx);
      setGameType(gType);
    }});
    newSocket.on('game_joined', ({{ gameId, playerIndex: pIdx, gameType: gType }}) => {{
      setGameCode(gameId);
      setPlayerIndex(pIdx);
      setGameType(gType);
    }});
    newSocket.on('game_state', (state) => setGameState(state));
    newSocket.on('error', ({{ message }}) => {{
      setError(message);
      setTimeout(() => setError(null), 3000);
    }});
    
    return () => {{
      if (socketRef.current) {{
        socketRef.current.close();
        socketRef.current = null;
      }}
    }};
  }}, []);

  const handleCreateGame = (playerName, gameConfig) => {{
    socket.emit('create_game', {{ playerName, gameConfig }});
  }};
  
  const handleJoinGame = (gameId, playerName) => {{
    socket.emit('join_game', {{ gameId, playerName }});
  }};

  const handleError = (message) => {{
    setError(message);
    setTimeout(() => setError(null), 3000);
  }};

  if (!gameState) {{
    return <GameSelectionLobby onCreateGame={{handleCreateGame}} onJoinGame={{handleJoinGame}} />;
  }}

  if (gameState.state === 'waiting') {{
    const maxPlayers = gameType === 'lorum' ? 4 : 3;
    return (
      <div className="lobby">
        <h1>{{gameType === 'lorum' ? '🃏 Lorum' : '🎴 Mexico'}}</h1>
        <div className="game-code">Code: {{gameCode}}</div>
        <div className="waiting-message">
          Waiting... ({{gameState.players.length}}/{{maxPlayers}})
          <br/><br/>
          {{gameState.players.map((p, i) => <div key={{i}}>{{i + 1}}. {{p.name}}</div>)}}
        </div>
      </div>
    );
  }}

  return (
    <div className="game-container">
      {{error && (
        <div style={{{{
          position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)',
          background: 'var(--red)', color: 'white', padding: '15px 30px',
          borderRadius: '8px', zIndex: 2000, fontWeight: 600
        }}}}>
          {{error}}
        </div>
      )}}
      
      <Chat socket={{socket}} gameCode={{gameCode}} playerIndex={{playerIndex}} />
      
      {{gameType === 'mexico' && (
        <MexicoGame 
          socket={{socket}} 
          gameState={{gameState}} 
          playerIndex={{playerIndex}} 
          gameCode={{gameCode}} 
          onError={{handleError}} 
        />
      )}}
      
      {{gameType === 'lorum' && (
        <LorumGame 
          socket={{socket}} 
          gameState={{gameState}} 
          playerIndex={{playerIndex}} 
          gameCode={{gameCode}} 
          onError={{handleError}} 
        />
      )}}
    </div>
  );
}}

ReactDOM.render(<GameCoordinator />, document.getElementById('root'));
'''

# Write final file
with open(OUTPUT_FILE, 'w') as f:
    f.write(final_app)

print(f"✅ Final app.js created: {OUTPUT_FILE}")
print(f"📊 File size: {len(final_app)} characters")
print("🚀 Ready to test!")
