// build.js - Combines modular source files into single app.js
const fs = require('fs');
const path = require('path');

const SRC_DIR = path.join(__dirname, 'public', 'src');
const OUTPUT_FILE = path.join(__dirname, 'public', 'app.js');

console.log('🔨 Building app.js from source files...');

// Read source files in order
const files = [
  'constants.js',
  'helpers.js',
  'components/Card.js',
  'components/GameHistory.js',
  'components/Chat.js',
  'components/GameSelectionLobby.js',
  'games/MexicoGame.js',
  'games/LorumGame.js',
  'GameCoordinator.js'
];

let combinedContent = '// Auto-generated from src/ - DO NOT EDIT DIRECTLY\n';
combinedContent += '// Edit files in public/src/ and run: npm run build\n\n';

for (const file of files) {
  const filePath = path.join(SRC_DIR, file);
  
  if (!fs.existsSync(filePath)) {
    console.error(`❌ Missing file: ${file}`);
    process.exit(1);
  }
  
  const content = fs.readFileSync(filePath, 'utf8');
  combinedContent += `\n// ============================================================================\n`;
  combinedContent += `// ${file}\n`;
  combinedContent += `// ============================================================================\n\n`;
  combinedContent += content + '\n';
  
  console.log(`✅ Added: ${file}`);
}

// Write combined file
fs.writeFileSync(OUTPUT_FILE, combinedContent);

console.log(`\n✨ Build complete!`);
console.log(`📄 Output: ${OUTPUT_FILE}`);
console.log(`📊 Size: ${(combinedContent.length / 1024).toFixed(2)} KB`);
