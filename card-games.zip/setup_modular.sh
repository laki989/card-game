#!/bin/bash
# setup_modular.sh - Sets up modular file structure

echo "🔨 Setting up modular file structure..."

BASE_DIR="/mnt/user-data/outputs"
SRC_DIR="$BASE_DIR/public/src"

# Create directories
mkdir -p "$SRC_DIR/components"
mkdir -p "$SRC_DIR/games"

echo "📁 Created source directories"

# Split current app.js into modular files
cd "$BASE_DIR"

# Extract and save GameSelectionLobby
echo "✂️  Extracting GameSelectionLobby..."
cat > "$SRC_DIR/components/GameSelectionLobby.js" << 'LOBBY_EOF'
function GameSelectionLobby({ onCreateGame, onJoinGame }) {
  const [playerName, setPlayerName] = useState('');
  const [gameCode, setGameCode] = useState('');
  const [showJoin, setShowJoin] = useState(false);
  const [selectedGame, setSelectedGame] = useState(null);
  const [contractMode, setContractMode] = useState('fixed');

  const games = [
    { id: 'mexico', name: 'Mexico', icon: '🎴', players: '3 players', description: 'Bidding and trick-taking game' },
    { id: 'lorum', name: 'Lorum', icon: '🃏', players: '4 players', description: '7 contracts compendium game' }
  ];

  const handleCreateWithGame = () => {
    if (!playerName || !selectedGame) return;
    const gameConfig = { 
      gameType: selectedGame,
      contractMode: selectedGame === 'lorum' ? contractMode : null
    };
    onCreateGame(playerName, gameConfig);
  };

  if (!selectedGame) {
    return (
      <div className="lobby">
        <h1>🎲 Card Games</h1>
        <input type="text" placeholder="Enter your name" value={playerName} onChange={(e) => setPlayerName(e.target.value)} />
        <div style={{ margin: '30px 0' }}>
          <h2 style={{ marginBottom: '15px', fontSize: '1.3rem' }}>Select a Game:</h2>
          <div style={{ display: 'flex', gap: '15px', flexDirection: 'column' }}>
            {games.map(game => (
              <div 
                key={game.id}
                onClick={() => playerName && setSelectedGame(game.id)}
                style={{
                  padding: '20px', background: 'white', borderRadius: '8px',
                  cursor: playerName ? 'pointer' : 'not-allowed',
                  opacity: playerName ? 1 : 0.5,
                  border: '3px solid var(--forest-dark)',
                  transition: 'all 0.2s',
                  display: 'flex', alignItems: 'center', gap: '15px'
                }}
                onMouseEnter={(e) => playerName && (e.currentTarget.style.transform = 'scale(1.02)')}
                onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
              >
                <div style={{ fontSize: '3rem' }}>{game.icon}</div>
                <div style={{ flex: 1, textAlign: 'left' }}>
                  <div style={{ fontSize: '1.5rem', fontWeight: 'bold', color: 'var(--forest-dark)' }}>
                    {game.name}
                  </div>
                  <div style={{ fontSize: '0.9rem', color: '#666', marginTop: '5px' }}>
                    {game.players} • {game.description}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="lobby-buttons">
          <button onClick={() => setShowJoin(!showJoin)}>
            {showJoin ? 'Cancel' : 'Join Existing Game'}
          </button>
          {showJoin && (
            <>
              <input type="text" placeholder="Enter game code" value={gameCode} onChange={(e) => setGameCode(e.target.value.toUpperCase())} />
              <button onClick={() => playerName && gameCode && onJoinGame(gameCode, playerName)} disabled={!playerName || !gameCode}>
                Join Game
              </button>
            </>
          )}
        </div>
      </div>
    );
  }

  const gameInfo = games.find(g => g.id === selectedGame);
  
  return (
    <div className="lobby">
      <h1>{gameInfo.icon} {gameInfo.name}</h1>
      <p style={{ fontSize: '1.1rem', marginBottom: '20px' }}>{gameInfo.description}</p>
      {selectedGame === 'lorum' && (
        <div style={{ background: 'white', padding: '20px', borderRadius: '8px', marginBottom: '20px', border: '2px solid var(--forest-dark)' }}>
          <h3 style={{ marginBottom: '15px', color: 'var(--forest-dark)' }}>Contract Mode:</h3>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button
              onClick={() => setContractMode('fixed')}
              style={{
                flex: 1, padding: '15px',
                background: contractMode === 'fixed' ? 'var(--gold)' : 'white',
                border: '2px solid var(--forest-dark)',
                borderRadius: '6px', cursor: 'pointer',
                fontWeight: contractMode === 'fixed' ? 'bold' : 'normal'
              }}
            >
              Fixed Order
              <div style={{ fontSize: '0.8rem', marginTop: '5px' }}>Play contracts 1→7</div>
            </button>
            <button
              onClick={() => setContractMode('choice')}
              style={{
                flex: 1, padding: '15px',
                background: contractMode === 'choice' ? 'var(--gold)' : 'white',
                border: '2px solid var(--forest-dark)',
                borderRadius: '6px', cursor: 'pointer',
                fontWeight: contractMode === 'choice' ? 'bold' : 'normal'
              }}
            >
              Player Choice
              <div style={{ fontSize: '0.8rem', marginTop: '5px' }}>Dealer picks contract</div>
            </button>
          </div>
        </div>
      )}
      <div className="lobby-buttons">
        <button onClick={handleCreateWithGame}>Create {gameInfo.name} Game</button>
        <button onClick={() => setSelectedGame(null)}>← Back to Game Selection</button>
      </div>
    </div>
  );
}
LOBBY_EOF

# Copy other components from the /games folder
cp "$BASE_DIR/public/games/MexicoGame.js" "$SRC_DIR/games/"
cp "$BASE_DIR/public/games/LorumGame.js" "$SRC_DIR/games/"

# Copy Chat and other components
cp "$BASE_DIR/public/components/GameHistory.js" "$SRC_DIR/components/" 2>/dev/null || echo "Note: GameHistory not in components folder"
cp "$BASE_DIR/public/components/Chat.js" "$SRC_DIR/components/" 2>/dev/null || echo "Note: Chat not in components folder"

echo "✅ Modular structure ready!"
echo ""
echo "📂 Structure:"
echo "  public/src/"
echo "    ├── constants.js"
echo "    ├── helpers.js"
echo "    ├── components/"
echo "    │   ├── Card.js"
echo "    │   ├── GameHistory.js"
echo "    │   ├── Chat.js"
echo "    │   └── GameSelectionLobby.js"
echo "    ├── games/"
echo "    │   ├── MexicoGame.js"
echo "    │   └── LorumGame.js"
echo "    └── GameCoordinator.js"
echo ""
echo "🔧 To rebuild app.js: npm run build"
echo "🔧 To watch for changes: npm run watch"
