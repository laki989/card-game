@echo off
echo Setting up Snops Card Game...

REM Create public directory if it doesn't exist
if not exist "public" mkdir public

REM Check if index.html is in the right place
if not exist "public\index.html" (
    if exist "index.html" (
        echo Moving index.html to public folder...
        move index.html public\
    ) else (
        echo ERROR: index.html not found!
        exit /b 1
    )
)

echo [OK] Folder structure created

REM Install dependencies
echo Installing dependencies...
call npm install

echo.
echo [OK] Setup complete!
echo.
echo To start the game server, run:
echo   npm start
echo.
echo Then open your browser to: http://localhost:3000
