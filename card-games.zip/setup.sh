#!/bin/bash

echo "Setting up Šnops Card Game..."

# Create public directory if it doesn't exist
mkdir -p public

# Check if index.html is in the right place
if [ ! -f "public/index.html" ]; then
    if [ -f "index.html" ]; then
        echo "Moving index.html to public folder..."
        mv index.html public/
    else
        echo "ERROR: index.html not found!"
        exit 1
    fi
fi

echo "✓ Folder structure created"

# Install dependencies
echo "Installing dependencies..."
npm install

echo ""
echo "✓ Setup complete!"
echo ""
echo "To start the game server, run:"
echo "  npm start"
echo ""
echo "Then open your browser to: http://localhost:3000"
