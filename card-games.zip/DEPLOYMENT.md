# Deployment Guide for Šnops Card Game

## Quick Deploy Options

### Option 1: Render.com (Recommended for Testing)
**Free, No Credit Card, Sleeps after 15min**

1. **Push to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin YOUR_GITHUB_REPO_URL
   git push -u origin main
   ```

2. **Deploy on Render:**
   - Go to https://render.com
   - Sign up with GitHub
   - Click "New +" → "Web Service"
   - Connect your repository
   - Settings will auto-detect from `render.yaml`
   - Click "Create Web Service"
   - Wait 2-3 minutes for deploy

3. **Access your game:**
   - Render gives you a URL like: `https://snops-card-game.onrender.com`
   - Share this URL with friends!

**Note:** Free tier sleeps after 15 min inactivity. First request after sleep takes ~30 seconds to wake up.

---

### Option 2: Railway.app
**$5 Free Credit/Month, No Sleep**

1. **Push to GitHub** (same as above)

2. **Deploy on Railway:**
   - Go to https://railway.app
   - Sign up with GitHub
   - Click "New Project" → "Deploy from GitHub repo"
   - Select your repo
   - Add credit card (required, but won't charge if under $5/month)
   - Auto-deploys!

3. **Get URL:**
   - Click "Settings" → "Generate Domain"
   - Share URL with friends

**Better for:** Multiple gaming sessions, no waiting for wake-up.

---

### Option 3: Glitch.com
**Instant Deploy, No Account Needed**

1. **No GitHub needed:**
   - Go to https://glitch.com
   - Click "New Project" → "Import from GitHub"
   - Paste your GitHub URL (or upload files directly)

2. **Or remix from terminal:**
   - Click "New Project" → "glitch-hello-node"
   - Delete their files
   - Upload your files via the file browser
   - Click "Tools" → "Terminal"
   - Run: `npm install`
   - Click "Show" → "In a New Window"

**Note:** Sleeps after 5 min inactivity. Good for quick tests.

---

### Option 4: Fly.io
**Production-Quality Free Tier**

1. **Install Fly CLI:**
   ```bash
   # Mac/Linux
   curl -L https://fly.io/install.sh | sh
   
   # Windows
   powershell -Command "iwr https://fly.io/install.ps1 -useb | iex"
   ```

2. **Deploy:**
   ```bash
   fly launch
   # Answer prompts:
   # - App name: snops-card-game
   # - Region: Choose closest to you
   # - Database: No
   
   fly deploy
   ```

3. **Get URL:**
   ```bash
   fly status
   # Shows your app URL
   ```

---

## After Deployment

### Share with Friends
Send them the URL provided by your hosting platform:
- Render: `https://your-app-name.onrender.com`
- Railway: `https://your-app-name.up.railway.app`
- Glitch: `https://your-project-name.glitch.me`
- Fly: `https://your-app-name.fly.dev`

### Important Notes
1. **First load may be slow** (especially Render/Glitch after sleep)
2. **WebSockets work** on all these platforms
3. **HTTPS is automatic** (required for modern browsers)
4. **Game state resets** when server restarts

### Troubleshooting

**"Cannot GET /"**
- Make sure `public` folder is in your repo
- Check that `index.html` is inside `public/`

**WebSocket connection failed**
- Check browser console for errors
- Hosting platform might not support WebSockets (all listed above do)

**Cards not showing**
- Make sure `public/img/` folder has all 33 images:
  - 32 card images (H-A.webp through A-07.webp)
  - 1 back.webp
- Push the img folder to GitHub

**Game crashes/disconnects**
- Check server logs on hosting platform
- Free tiers have memory limits (512MB usually)
- 3 players should be fine

---

## Recommended Path

1. **Today:** Test locally with `npm start`, play with 3 browser tabs
2. **Tomorrow:** Push to GitHub, deploy to Render.com
3. **Test with friends:** Share Render URL
4. **If you like it:** Upgrade to Railway for no-sleep experience
5. **Going live:** Consider paid hosting for reliability

---

## Cost Comparison

| Platform | Free Tier | Sleep? | Needs Card? | Best For |
|----------|-----------|--------|-------------|----------|
| Render | 750 hrs/mo | Yes (15min) | No | Quick testing |
| Railway | $5 credit | No | Yes (no charge) | Regular play |
| Glitch | Unlimited | Yes (5min) | No | Instant demo |
| Fly.io | 3 VMs | No | Yes | Production-like |

All options are **100% free** for your testing needs!
